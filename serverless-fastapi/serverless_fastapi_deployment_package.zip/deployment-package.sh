pip install --target ./package -r requirements.txt
export PATH=$PATH:"C:\Program Files\7-Zip"
rm serverless_fastapi_deployment_package.zip
cd package
7z a ../serverless_fastapi_deployment_package.zip .
rm -r package
cd ..
7z a serverless_fastapi_deployment_package.zip .
# TODO: add cleanup